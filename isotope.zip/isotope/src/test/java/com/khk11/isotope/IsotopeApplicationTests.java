package com.khk11.isotope;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsotopeApplicationTests {

	@Test
	void contextLoads() {
	}

}
